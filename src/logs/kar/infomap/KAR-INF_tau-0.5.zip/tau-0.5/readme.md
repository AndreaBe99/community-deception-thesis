```python
class FilePaths(Enum):
    """Class to store file paths for data and models"""
    # ° Local
    # DATASETS_DIR = 'dataset/data'
    # LOG_DIR    = 'src/logs/'
    # TEST_DIR = 'test/'
    # ° Kaggle
    DATASETS_DIR = '/kaggle/input/network-community'
    LOG_DIR = '/kaggle/working/logs/'
    TEST_DIR = '/kaggle/working/test/'
    # ° Google Colab
    # DATASETS_DIR = "/content/drive/MyDrive/Sapienza/Tesi/Datasets"
    # LOG_DIR = "/content/drive/MyDrive/Sapienza/Tesi/Logs/"
    # TEST_DIR = "/content/drive/MyDrive/Sapienza/Tesi/Test/"

    # Dataset file paths
    KAR = DATASETS_DIR + '/kar.mtx'
    DOL = DATASETS_DIR + '/dol.mtx'
    MAD = DATASETS_DIR + '/mad.mtx'
    LESM = DATASETS_DIR + '/lesm.mtx'
    POLB = DATASETS_DIR + '/polb.mtx'
    WORDS = DATASETS_DIR + '/words.mtx'
    ERDOS = DATASETS_DIR + '/erdos.mtx'
    POW = DATASETS_DIR + '/pow.mtx'
    FB_75 = DATASETS_DIR + '/fb-75.mtx'
    DBLP = DATASETS_DIR + '/dblp.mtx'
    ASTR = DATASETS_DIR + '/astr.mtx'
    AMZ = DATASETS_DIR + '/amz.mtx'
    YOU = DATASETS_DIR + '/you.mtx'
    ORK = DATASETS_DIR + '/ork.mtx'


class HyperParams(Enum):
    """Hyperparameters for the Environment"""
    # Numeber of possible action with BETA=30, is 30% of the edges
    BETA = 10
    # Strength of the deception constraint, value between 0 and 1,
    # with 1 soft constraint, 0 hard constraint
    TAU = 0.5
    # ° Hyperparameters  Testing ° #
    # Weight to balance the penalty in the reward
    LAMBDA = [0.01, 0.1, 1]
    # Weight to balance the two metrics in the definition of the penalty
    ALPHA = [0.3, 0.5, 0.7]

    """ Graph Encoder Parameters """""
    EMBEDDING_DIM = 128 # 256

    """ Agent Parameters"""
    # Networl Architecture
    HIDDEN_SIZE_1 = 64
    HIDDEN_SIZE_2 = 32

    # Hyperparameters for the ActorCritic
    EPS_CLIP = np.finfo(np.float32).eps.item()  # 0.2
    BEST_REWARD = 0.7  # -np.inf
    # ° Hyperparameters  Testing ° #
    LR = [1e-3, 1e-2, 1e-1]
    GAMMA = [0.3, 0.5, 0.7]


    """ Training Parameters """
    # Number of episodes to collect experience
    MAX_EPISODES = 1000
    # Dictonary for logging
    LOG_DICT = {
        'train_reward': [],
        # Number of steps per episode
        'train_steps': [],
        # Average reward per step
        'train_avg_reward': [],
        # Average Actor loss per episode
        'a_loss': [],
        # Average Critic loss per episode
        'v_loss': [],
        # set max number of training episodes
        'train_episodes': MAX_EPISODES,
    }

    """Evaluation Parameters"""
    LR_EVAL = 1e-3
    GAMMA_EVAL = 0.3
    LAMBDA_EVAL = 0.1
    ALPHA_EVAL = 0.3
    STEPS_EVAL = 1000
    EVAL_DICT = {
        "agent": {
            "goal": [],
            "nmi": [],
            "time": [],
            "steps": [],
            "lr": None,
            "gamma": None,
            "lambda_metric": None,
            "alpha_metric": None,
        },
        "rh": {
            "goal": [],
            "nmi": [],
            "time": [],
            "steps": [],
        },
        "dh": {
            "goal": [],
            "nmi": [],
            "time": [],
            "steps": [],
        },
        "di": {
            "goal": [],
            "nmi": [],
            "time": [],
            "steps": [],
        },
    }

    """Graph Generation Parameters"""
    N_NODE = 10000
    TAU1 = 3
    TAU2 = 1.5
    MU = 0.1             # TODO: Test also 0.3 and 0.6
    AVERAGE_DEGREE = 5
    MIN_COMMUNITY = 20
    SEED= 10
```